/**
 * @(#)Assesement.java
 *
 * assesement - simple menu with 2 various options to ascend/descend to sort, efficiency test (performance) and ability to see the list, auto-populate the array and quit of the menu
 *
 * @author Mateusz Jakusz - HNCC - Programming
 * @version 1.00 2018/12/4
 */
// importing all classes required for project
import java.util.*; 

public class Assesement {
	// needed for not overloading the database
	static int size = 0;
    public static void main(String[] args) {
    	// displays menu to user
    	System.out.println(" PLEASE SELECT FROM 1-9 ");
    	System.out.println("1. Add a name to the list");
    	System.out.println("2. Sort the list ascending using insertion sort");
    	System.out.println("3. Sort the list descending using insertion sort");
    	System.out.println("4. Sort the list ascending using built-in Java method");
    	System.out.println("5. Sort the list descending using built-in Java method");
    	System.out.println("6. Display the list");
    	System.out.println("7. Populate the database with random 100000 entries");
    	System.out.println("8. Run efficiency test");
    	System.out.println("9. Exit the programme");
    	// setting a scanner to take input from user
		Scanner sc = new Scanner(System.in); 
		// initialized empty database (list)
		String[] database = new String[10000]; 
    	//initializing the menu choice system to handle user commands
		// setting a boolean variable that quits the menu
    	boolean quit = false; 
    	int menuItem;
    		do {
    			System.out.print("Choose menu item: ");
                 menuItem = sc.nextInt();
                  switch (menuItem) {
                  case 1:
					    addName(database);
                        break;

                  case 2:
                	  	// check if databse is empty
                	  	if (database[1] == null) { 
                	  		System.out.print("Please make sure database is full before running the method.");
                	  		break;
                	  	}
						insertionSortAsc(database);
						System.out.println("Database sorted in ascending way:");
                        break;

                  case 3:
                	  	if (database[1] == null) {
                	  		System.out.print("Please make sure database is full before running the method.");
                	  		break;
                	  	}
						insertionSortDsc(database);
						System.out.println("Database sorted in descending way:");
                        break;

                  case 4:
                	  	if (database[1] == null) {
                	  		System.out.print("Please make sure database is full before running the method.");
                	  		break;
                	  	}
						javaSortAsc(database);
						System.out.println("Database sorted in ascending way:");
                        break;

                  case 5:
                	  	if (database[1] == null) {
                	  		System.out.print("Please make sure database is full before running the method.");
                	  		break;
                	 	}
						javaSortDsc(database);
						System.out.println("Database sorted in descending way:");

                        break;
                  case 6:
						displayList(database);

                       break;
                  case 7:
						autoPopulate(database);

                       break;
                  case 8:
              	  		if (database[1] == null) {
            	  		System.out.print("Please make sure database is full before running the method.");
            	  		break;
              	  		}
                	  	// simple timer to show the time of run test
                	  	final long startTime = System.currentTimeMillis();
                	  	insertionSortAsc(database);
                	  	insertionSortDsc(database);
                	  	javaSortAsc(database);
                	  	javaSortDsc(database);
                	  	final long endTime = System.currentTimeMillis();
                	  	System.out.println("Total execution time: " + (endTime - startTime) + "miliseconds");
                       break;
                  case 9:
                	// setting a boolean to true for quiting the menu
                        quit = true; 
                        break;
                    // prevent user from choosing wrong option
                  default: 

                        System.out.println("Invalid choice. Please try again selecting the option 1-9");

                  }

            } while (!quit);
            // menu ENDS
            System.out.println("Thank you so much for using my program!");

    }
// addName Method for adding names into the database
public static void addName(String[] data){
	if(size >= data.length) {
		// protection for overwrite
		System.out.println("Database too big"); 
		return;
	}
	Scanner sc = new Scanner(System.in);
	System.out.println("Please enter the name you want to add to the list");
	String name = sc.next();
	data[size]=name;
	size++;
	System.out.println(name + " was added to the array.");
}

// sorting in ascending oder using Java method
public static void javaSortAsc(String[] data) {
	Arrays.sort(data);
}
//sorting in descending order using Java method
public static void javaSortDsc(String[] data){
	Arrays.sort(data, Collections.reverseOrder());

}
// sorting in ascending order using insertionSort algorithm
public static void insertionSortAsc (String[] data) {
	// temp variable for single array entry
	String temp; 
          for(int i = 1; i < data.length; i++) {
               temp = data[i];
               int j = 0;
               	for(j = i; j > 0; j--) {
               		if(temp.compareTo(data[j - 1]) < 0) {
                         data[j] = data[j - 1];
                    }
                    else {
                    break;
                    }

          	   }
               data[j] = temp;
          }
}
// sorting in ascending order using instertionSort algorithm
public static void insertionSortDsc (String[] data) {
	// temp variable for single array entry
	String temp; 
		for(int i = 1; i < data.length; i++) {
        temp = data[i];
        int j = 0;
        	for(j = i; j > 0; j--) {
        		if(temp.compareTo(data[j - 1]) > 0) {
                  data[j] = data[j - 1];
        		}
        		else {
        			break;
        		}

        	}
        data[j] = temp;
       }
}
// simple method using for-loop to print all the entries of array
public static void displayList(String[] data) {
	System.out.println("Displaying database:");
	// using for loop to print data inside list
	for(int i= 0; i < data.length; i++) { 
		System.out.println(data[i]);
	}
}
// method for populating the array using random generated numbers in range 0-10000
public static void autoPopulate(String[] data) {
	for(int i = 0 ; i < data.length; i++) {
		// generate random number in range 0-10000
		int random = (int)(Math.random() * 10000);
		// converting int to string 
		String numberAsString = Integer.toString(random); 
		data[i] = numberAsString;
}
	System.out.println("Database populated with 10000 entries.");
}
// end of program
}